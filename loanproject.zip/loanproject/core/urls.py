from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # ← Add this
    path('dashboard/', views.dashboard, name='dashboard'),
    path('apply/', views.apply_loan, name='apply'),
    path('loan/step1/', views.loan_step1, name='loan_step1'),
    path('loan/step2/', views.loan_step2, name='loan_step2'),
    path('loan/step3/', views.loan_step3, name='loan_step3'),
    path('loans/history/', views.loan_history, name='loan_history'),


]