from django.contrib import admin
from .models import UserProfile, Loan

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'loan_limit', 'total_loan')

@admin.register(Loan)
class LoanAdmin(admin.ModelAdmin):
    list_display = ('user', 'amount', 'status', 'months', 'interest', 'created_at')
    list_editable = ('interest',)  # ← Admin page থেকে interest changeable
    list_filter = ('status', 'created_at')

    def approve_loan(self, request, queryset):
        queryset.update(status='Approved')
        for loan in queryset:
            profile, created = UserProfile.objects.get_or_create(user=loan.user)
            profile.total_loan += loan.amount
            profile.save()
    approve_loan.short_description = "Approve selected loans"

    def reject_loan(self, request, queryset):
        queryset.update(status='Rejected')
    reject_loan.short_description = "Reject selected loans"