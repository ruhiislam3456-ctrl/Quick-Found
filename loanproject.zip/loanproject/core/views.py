from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import UserProfile, Loan


def home(request):
    return render(request, 'home.html')

@login_required
def apply_loan(request):
    # এই page এ তুমি চাইলে “Step1” এ redirect করতে পারো
    return redirect('loan_step1')

# Dashboard with Loan Limit & Total Loan
@login_required
def dashboard(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    context = {
        'loan_limit': profile.loan_limit,
        'total_loan': profile.total_loan
    }
    return render(request, 'dashboard.html', context)

# Loan Apply Step 1 → Personal Info
@login_required
def loan_step1(request):
    if request.method == "POST":
        request.session['full_name'] = request.POST.get('full_name')
        request.session['phone'] = request.POST.get('phone')
        return redirect('loan_step2')
    return render(request, 'loan_step1.html')

# Loan Apply Step 2 → Amount, Purpose, Months, Interest
@login_required
def loan_step2(request):
    if request.method == "POST":
        request.session['amount'] = float(request.POST.get('amount'))
        request.session['months'] = int(request.POST.get('months'))
        request.session['interest'] = 7.6  # ← Hardcode default, user cannot change
        return redirect('loan_step3')
    return render(request, 'loan_step2.html')

# Loan Apply Step 3 → Summary + Monthly Installment + Total Payment
@login_required
def loan_step3(request):
    if request.method == "POST":
        # Save Loan in DB
        Loan.objects.create(
            user=request.user,
            full_name=request.session['full_name'],
            phone=request.session['phone'],
            amount=request.session['amount'],
            months=request.session['months'],
            interest=request.session['interest']
        )
        return redirect('dashboard')

    # Backend calculation
    amount = request.session.get('amount', 0)
    months = request.session.get('months', 1)
    interest = request.session.get('interest', 0)

    total_interest = amount * interest / 100 * months
    total_payment = amount + total_interest
    monthly_payment = total_payment / months

    context = {
        'full_name': request.session.get('full_name'),
        'phone': request.session.get('phone'),
        'amount': amount,
        'months': months,
        'interest': interest,
        'monthly_payment': round(monthly_payment, 2),
        'total_payment': round(total_payment, 2)
    }
    return render(request, 'loan_step3.html', context)

# User Loan History
@login_required
def loan_history(request):
    loans = Loan.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'loan_history.html', {'loans': loans})