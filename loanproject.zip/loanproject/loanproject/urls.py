from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),

    # Django built-in login/logout
    path('accounts/', include('django.contrib.auth.urls')),

    path('', include('core.urls')),
]